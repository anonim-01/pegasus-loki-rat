class Backup < ApplicationRecord
  belongs_to :smartphone

  enum backup_type: { full: 0, apps: 1, shared: 2, system: 3 }
  enum status: { pending: 0, processing: 1, completed: 2, failed: 3 }

  store :extracted_data, accessors: [:sms, :calls, :contacts, :location, :whatsapp, :apps, :browser], coder: JSON

  validates :backup_type, presence: true
  validates :status, presence: true

  before_create :set_default_status

  private

  def set_default_status
    self.status ||= :pending
  end
end

