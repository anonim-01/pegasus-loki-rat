class CallLog < ApplicationRecord
  belongs_to :smartphone
end

