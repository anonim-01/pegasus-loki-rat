class Contact < ApplicationRecord
  belongs_to :smartphone
end

