namespace PEGASUS.Design.RenamingObfuscation.Overkill.Utils.Analyzer
{
	public abstract class DefAnalyzer
	{
		public abstract bool Execute(object context);
	}
}
