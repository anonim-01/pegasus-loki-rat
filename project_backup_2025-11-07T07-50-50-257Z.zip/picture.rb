class Picture < ApplicationRecord
  belongs_to :smartphone
end

