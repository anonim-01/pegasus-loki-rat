class Recording < ApplicationRecord
  belongs_to :smartphone
end

