class Screenshot < ApplicationRecord
  belongs_to :smartphone
end

