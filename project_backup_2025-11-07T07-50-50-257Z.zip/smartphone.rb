class Smartphone < ApplicationRecord
  belongs_to :apk_installation
  has_many :backups, dependent: :destroy
end

