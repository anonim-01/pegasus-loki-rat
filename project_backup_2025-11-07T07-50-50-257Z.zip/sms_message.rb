class SmsMessage < ApplicationRecord
  belongs_to :smartphone
end

